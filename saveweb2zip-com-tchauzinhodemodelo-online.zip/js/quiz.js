(function () {
  // Configurações e URLs padrão (podem ser substituídos por parâmetros)
  const AVATAR_URL = 'assets/avatar-brenda.png';
  const AVATAR_FALLBACK_URL = 'https://i.imgur.com/uW4Xb2s.png';
  const CHECKOUT_URL = (typeof window !== 'undefined' && window.CHECKOUT_URL_OVERRIDE) || 'https://pay.kiwify.com.br/eQ52561';
  const TOTAL_STEPS = 15;
  const VARIANT = (typeof window !== 'undefined' && window.FUNNEL_VARIANT) || 'DESAFIO';

  const chatContainer = document.getElementById('chatContainer');
  const chatMessages = document.getElementById('chatMessages');
  const progressBar = document.getElementById('progressBar');

  let sessionId = 'local-quiz-session-' + Math.random().toString(36).substring(2, 9);
  let currentStep = 0;
  let vars = {};

  // --- Recuperar parâmetros da URL ---
  function getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    return {
      utm_source: params.get('utm_source') || '',
      utm_medium: params.get('utm_medium') || '',
      utm_campaign: params.get('utm_campaign') || '',
      utm_content: params.get('utm_content') || '',
      fbclid: params.get('fbclid') || '',
      referrer: document.referrer || '',
      user_agent: navigator.userAgent || '',
      variant: VARIANT,
    };
  }

  // --- API Helpers (Mockados para funcionar 100% offline/estático sem erros no console) ---
  async function apiPost(url, data) {
    console.log(`[Tracking API Post] ${url}`, data);
    return { success: true, sessionId };
  }

  async function startSession() {
    const params = getUrlParams();
    await apiPost('/api/session/start', params);
  }

  async function sendAnswer(stepNumber, stepName, answer) {
    await apiPost(`/api/session/${sessionId}/answer`, { stepNumber, stepName, answer });
  }

  async function sendEvent(eventType, eventData) {
    await apiPost(`/api/session/${sessionId}/event`, { eventType, eventData });
  }

  async function completeSession() {
    await apiPost(`/api/session/${sessionId}/complete`, {});
  }

  function apiBeacon(url, data) {
    console.log(`[Tracking API Beacon] ${url}`, data);
    try {
      if (navigator.sendBeacon) {
        const blob = new Blob([JSON.stringify(data || {})], { type: 'application/json' });
        return navigator.sendBeacon(url, blob);
      }
    } catch (e) {}
    return false;
  }

  // --- Barra de Progresso ---
  function updateProgress(step) {
    const pct = ((step + 1) / TOTAL_STEPS) * 100;
    progressBar.style.width = Math.min(pct, 100) + '%';
  }

  // --- Controle de Scroll ---
  function scrollToBottom() {
    setTimeout(() => {
      chatContainer.scrollTo({
        top: chatContainer.scrollHeight,
        behavior: 'smooth'
      });
    }, 50);
  }

  function scrollToCenter(element) {
    setTimeout(() => {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }, 100);
  }

  // --- Substituição de Variáveis de Template ---
  function tpl(str) {
    return str
      .replace(/\{\{objetivo\}\}/g, vars.objetivo || '')
      .replace(/\{\{pesoIdeal\}\}/g, vars.pesoIdeal || '')
      .replace(/\{\{pesoAtual\}\}/g, vars.pesoAtual || '')
      .replace(/\{\{altura\}\}/g, vars.altura || '')
      .replace(/\{\{dataFutura\}\}/g, getFutureDate());
  }

  function getFutureDate() {
    const d = new Date();
    d.setDate(d.getDate() + 31);
    const months = [
      'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
      'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
    ];
    return d.getDate() + ' de ' + months[d.getMonth()];
  }

  // --- Indicador de Digitação (Typing Indicator) ---
  function showTyping() {
    const group = document.createElement('div');
    group.className = 'bot-group';
    group.id = 'typing-indicator';

    const avatar = document.createElement('img');
    avatar.src = AVATAR_URL;
    avatar.onerror = function() {
      avatar.src = AVATAR_FALLBACK_URL;
    };
    avatar.className = 'bot-avatar';
    avatar.alt = 'Nutri Brenda';

    const bubble = document.createElement('div');
    bubble.className = 'typing-bubble';
    bubble.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';

    group.appendChild(avatar);
    group.appendChild(bubble);
    chatMessages.appendChild(group);
    scrollToBottom();
  }

  // Ocultar Indicador
  function hideTyping() {
    const el = document.getElementById('typing-indicator');
    if (el) el.remove();
  }

  // --- Delay de digitação baseado no tamanho do texto ---
  function getTypingDelay(text) {
    const clean = text.replace(/<[^>]*>/g, '').replace(/IMG:.*/g, '');
    const len = clean.length;
    if (len === 0) return 900;
    if (len < 30) return 600;
    if (len < 60) return 1000;
    if (len < 100) return 1400;
    if (len < 150) return 1800;
    return 2200;
  }

  // --- Renderização de Mensagens do Bot ---
  function addBotMessage(msg, showAvatar) {
    const group = document.createElement('div');
    group.className = 'bot-group';

    if (showAvatar) {
      const avatar = document.createElement('img');
      avatar.src = AVATAR_URL;
      avatar.onerror = function() {
        avatar.src = AVATAR_FALLBACK_URL;
      };
      avatar.className = 'bot-avatar';
      avatar.alt = 'Nutri Brenda';
      group.appendChild(avatar);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'bot-avatar-placeholder';
      group.appendChild(placeholder);
    }

    const bubblesContainer = document.createElement('div');
    bubblesContainer.className = 'bot-bubbles';

    const bubble = document.createElement('div');
    bubble.className = 'bot-bubble';

    const rendered = tpl(msg);
    if (rendered.startsWith('IMG:')) {
      const img = document.createElement('img');
      const originalUrl = rendered.substring(4);
      // Mapeia URL original para local asset
      let localUrl = '';
      if (originalUrl.includes('0j6TFoN')) {
        localUrl = 'assets/grafico-ganho.png';
      } else if (originalUrl.includes('w7fvgtyd0z') || originalUrl.includes('chz2Yr4g')) {
        localUrl = 'assets/grafico-perda.png';
      }
      
      img.src = localUrl || originalUrl;
      img.onerror = function() {
        img.src = originalUrl;
      };
      img.alt = 'Gráfico de resultados';
      bubble.appendChild(img);
    } else {
      bubble.innerHTML = rendered;
    }

    bubblesContainer.appendChild(bubble);
    group.appendChild(bubblesContainer);
    chatMessages.appendChild(group);
    scrollToBottom();
  }

  async function addBotMessages(messages, showAvatar) {
    for (let i = 0; i < messages.length; i++) {
      showTyping();
      scrollToBottom();
      await sleep(getTypingDelay(messages[i]));
      hideTyping();
      addBotMessage(messages[i], showAvatar && i === 0);
      if (i < messages.length - 1) {
        await sleep(350);
      }
    }
  }

  // --- Renderização de Balão da Usuária ---
  function addGuestBubble(text) {
    const bubble = document.createElement('div');
    bubble.className = 'guest-bubble';
    bubble.textContent = text;
    chatMessages.appendChild(bubble);
    scrollToBottom();
  }

  // --- Renderizar Botões de Escolha ---
  function showChoices(options) {
    return new Promise((resolve) => {
      const container = document.createElement('div');
      container.className = 'choices-container';

      options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'choice-btn';
        btn.textContent = opt;
        btn.style.animationDelay = (idx * 150) + 'ms';

        btn.addEventListener('click', () => {
          container.classList.add('fade-out');
          setTimeout(() => {
            container.remove();
            addGuestBubble(opt);
            resolve(opt);
          }, 300);
        });

        container.appendChild(btn);
      });

      chatMessages.appendChild(container);
      scrollToCenter(container);
    });
  }

  // --- Renderizar Botão de Link (Checkout) ---
  function showLinkButton(text, href, id, classes) {
    return new Promise((resolve) => {
      const container = document.createElement('div');
      container.className = 'choices-container';

      const link = document.createElement('a');
      link.className = (classes || 'choice-btn');
      link.id = id;
      link.href = href;
      link.textContent = text;
      link.style.animationDelay = '0ms';
      link.rel = 'noopener';

      link.addEventListener('click', () => {
        resolve({ text: text, href: href });
      });

      container.appendChild(link);
      chatMessages.appendChild(container);
      scrollToCenter(container);
    });
  }

  // --- Renderizar Campo Numérico ---
  function showNumberInput(placeholder, min, max) {
    return new Promise((resolve) => {
      const container = document.createElement('div');
      container.className = 'number-input-container';

      const input = document.createElement('input');
      input.type = 'number';
      input.placeholder = placeholder;
      input.min = min;
      input.max = max;
      input.inputMode = 'numeric';

      const btn = document.createElement('button');
      btn.textContent = 'Enviar';

      function submit() {
        const val = parseInt(input.value);
        if (isNaN(val) || val < min || val > max) {
          input.style.boxShadow = '0 0 0 2px #ef4444';
          setTimeout(() => {
            input.style.boxShadow = '';
          }, 1000);
          return;
        }
        container.classList.add('fade-out');
        setTimeout(() => {
          container.remove();
          addGuestBubble(String(val));
          resolve(String(val));
        }, 300);
      }

      btn.addEventListener('click', submit);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') submit();
      });

      container.appendChild(input);
      container.appendChild(btn);
      chatMessages.appendChild(container);
      scrollToCenter(container);

      setTimeout(() => input.focus(), 150);
    });
  }

  // --- Definição do Fluxo de Quiz ---
  const flow = [
    {
      stepName: 'frustracao',
      variableToSave: 'frustracao',
      messages: [
        'Oi! 🩷 Sabe aquela <b>blusinha sem manga</b> ou aquele <b>vestido de alcinha</b> que você evita usar por vergonha do braço balançando?',
        'Eu sou a <b>Nutri Brenda</b>, especialista em tonificação localizada, e ajudo mulheres a afinar os braços e darem um fim definitivo à flacidez no tríceps e axilas, no conforto de casa.',
        'Se você chegou até aqui, é porque <b>não aguenta mais se olhar no espelho</b> e sentir insegurança com os braços gordos ou flácidos, sentir o braço todo balançando ao dar tchau ou aquela gordurinha chata que salta da axila, tô certa?',
        '👇 Para eu personalizar seu plano, me conta: <b>qual é a sua maior frustração hoje?</b>'
      ],
      inputType: 'choice',
      options: [
        'Meu braço balança muito ao dar tchau',
        'Sofro com a gordurinha na axila e nas costas',
        'Minha pele está muito flácida',
        'Tenho vergonha de colocar blusa sem manga'
      ]
    },
    {
      stepName: 'situacao_bracos',
      messages: ['<b>Entendi. E como você descreveria a situação dos seus braços hoje?</b>'],
      inputType: 'choice',
      options: [
        'Gordinho e com flacidez',
        'Fino, mas muito mole (falta firmeza)',
        'Normal, mas quero definir e tonificar',
        'Gordura concentrada mais nas axilas e costas'
      ]
    },
    {
      stepName: 'tentou_antes',
      messages: ['<b>Você sente que já tentou de tudo para afinar os braços e nada funciona?</b>'],
      inputType: 'choice',
      options: [
        'Já paguei academia e não vi diferença nos braços',
        'Sim, já tentei dietas e sinto que a genética não ajuda',
        'Faço caminhada/treino, mas o braço continua flácido',
        'Ainda não tentei a sério, mas não sei por onde começar'
      ]
    },
    {
      stepName: 'braco_sonhos',
      messages: [
        '<i>Não importa o seu nível atual, o <b>Desafio do Tchauzinho</b> vai transformar seus resultados!</i>',
        '<b>Qual é o seu "braço dos sonhos"?</b>'
      ],
      inputType: 'choice',
      options: ['Fininho e delicado', 'Firme e sem balançar nada', 'Desenhado e tonificado', 'Todas as alternativas']
    },
    {
      stepName: 'roupa_saudade',
      messages: ['<b>Qual roupa você sente saudade de vestir ou gostaria de voltar a usar sem nenhuma insegurança?</b>'],
      inputType: 'choice',
      options: ['Regatinha de alça fina', 'Vestido sem manga', 'Biquíni']
    },
    {
      stepName: 'tempo_confortavel',
      messages: ['<b>Há quanto tempo você não se sente 100% confortável e confiante de deixar os braços de fora?</b>'],
      inputType: 'choice',
      options: ['Há menos de 1 ano', 'Há mais de 1 ano', 'Há muitos anos', 'Já nem lembro como é']
    },
    {
      stepName: 'tempo_treino',
      messages: [
        '<b>Para os seus treinos, quanto tempo você tem disponível por dia?</b>',
        '<i>(Precisamos adaptar a sua vida corrida 💕)</i>'
      ],
      inputType: 'choice',
      options: ['10 a 15 minutos', '20 a 30 minutos', 'Mais de 30 minutos']
    },
    {
      stepName: 'horas_sono',
      messages: [
        '<b>Perfeito! Já estou terminando o seu plano.</b>',
        '<b>Quantas horas você dorme por noite?</b>'
      ],
      inputType: 'choice',
      options: ['Menos de 6h', '6h a 8h', 'Mais de 8h']
    },
    {
      stepName: 'idade',
      messages: ['Agora, para o sistema <b>calcular a sua taxa metabólica</b> e liberar o cronograma exato para a tonificação dos seus braços, <b>qual é a sua idade?</b>'],
      inputType: 'choice',
      options: ['25 a 29 anos', '30 a 40 anos', '40 a 50 anos', 'Mais de 50 anos']
    },
    {
      stepName: 'altura',
      variableToSave: 'altura',
      messages: ['<b>Qual a sua altura em cm?</b>'],
      inputType: 'number',
      placeholder: 'Ex: 165',
      min: 140,
      max: 220
    },
    {
      stepName: 'peso_atual',
      variableToSave: 'pesoAtual',
      messages: ['<b>Qual é o seu peso atualmente em kgs?</b>'],
      inputType: 'number',
      placeholder: 'Ex: 70',
      min: 30,
      max: 300
    },
    {
      stepName: 'peso_ideal',
      variableToSave: 'pesoIdeal',
      messages: ['Entendi! <b>E qual é o seu objetivo de peso para se sentir maravilhosa?</b>'],
      inputType: 'number',
      placeholder: 'Ex: 60',
      min: 30,
      max: 300
    },
    {
      stepName: 'plano_pronto',
      messages: [
        '<b>Seu Plano do Desafio do Tchauzinho está pronto! 🔥</b>',
        'De acordo com o seu metabolismo e suas respostas...',
        'Prevemos que você estará com os <b>braços finos, definidos e muito mais firmes em poucas semanas.</b>',
      ],
      getExtraMessages: function () {
        const pesoAtual = parseFloat(vars.pesoAtual) || 0;
        const pesoIdeal = parseFloat(vars.pesoIdeal) || 0;
        // Gráfico condicional conforme meta
        const grafico = pesoIdeal >= pesoAtual
          ? 'IMG:https://i.imgur.com/0j6TFoN.jpeg'
          : 'IMG:https://i.ibb.co/chz2Yr4g/w7fvgtyd0z8197w9y7ib08zt.png';
        return [grafico, '<b>Você está preparada para voltar a usar as roupas que ama, chamar atenção por onde passa e se sentir linda no espelho?</b>'];
      },
      inputType: 'choice',
      options: ['SIM, CLARO!']
    },
    {
      stepName: 'aceite_desafio',
      messages: [
        'Você receberá <b>acesso imediato ao aplicativo</b> com treinos focados exclusivamente na <b>tonificação dos membros superiores!</b> 📲',
        '<b>✅ Fim do "tchauzinho" mole</b><br><b>✅ Braços finos e definidos</b><br><b>✅ Redução das gordurinhas nas axilas e costas</b><br><b>✅ Protocolos rápidos para você fazer na sala de casa</b><br><b>✅ Acesso Vitalício</b>',
        '<b>Você está pronta para conquistar braços firmes e resgatar sua autoestima?</b>'
      ],
      inputType: 'choice',
      options: ['SIM, EU QUERO MEUS BRAÇOS FIRMES!']
    },
    {
      stepName: 'checkout',
      messages: [
        'A gente sabe que personal trainer, academia lotada e nutricionista custam mais de <b>R$ 300,00 por mês</b>. É um perrengue e, no fim, você acaba desistindo...',
        'Por isso, o <b>Desafio de 21 Dias não tem mensalidade NENHUMA</b>. Você paga uma vez só e o acesso ao aplicativo é seu pra sempre.',
        'Para cobrir os custos da plataforma, cobramos apenas uma <b>taxa de inscrição única de R$ 37,00</b>. <i>Menos que um pedido no iFood</i> pra você fazer inveja a todas as suas amigas!',
        'E não tem risco: se em <b>30 dias</b> você aplicar o método e não sentir seus braços mais firmes e a roupa mais larga, eu <b>devolvo 100% do seu dinheiro</b>. Sem letras miúdas.',
        '🎁 E tem mais! Entrando para o Desafio <b>HOJE</b>, eu vou te dar <b>2 bônus exclusivos totalmente de graça</b>:',
        '✅ <b>Guia Alimentar Seca-Braço</b> — alimentos específicos que aceleram a queima da gordura localizada nos membros superiores.<br>✅ <b>Rotina Antiflacidez</b> — um protocolo matinal de 3 minutos para ativar o colágeno e firmar a pele.',
        'Mas atenção: esse valor e os bônus são <b>válidos somente hoje</b> enquanto a turma está aberta, corre que as vagas estão acabando. Assim que finalizar, já libero o aplicativo na hora no seu WhatsApp! 💕'
      ],
      inputType: 'link',
      linkText: 'QUERO MEUS BRAÇOS FIRMES AGORA!',
      linkId: 'cta-checkout-desafio',
      linkClass: 'choice-btn cta-checkout',
    }
  ];

  // --- Função para repassar os parâmetros de URL para o link final da Hotmart ---
  function getParam(key) {
    return new URLSearchParams(window.location.search).get(key) || '';
  }

  function buildCheckoutUrl() {
    var finalUrl = CHECKOUT_URL;
    var params = [];
    var keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'xcod', 'fbclid', 'sck', 'src', 'gclid'];
    
    keys.forEach(function (key) {
      var val = getParam(key);
      if (val) params.push(key + '=' + encodeURIComponent(val));
    });

    var urlParams = new URLSearchParams(window.location.search);
    urlParams.forEach(function (val, key) {
      if (keys.indexOf(key) === -1) {
        params.push(key + '=' + encodeURIComponent(val));
      }
    });

    if (params.length > 0) {
      var separator = finalUrl.indexOf('?') === -1 ? '?' : '&';
      finalUrl += separator + params.join('&');
    }
    return finalUrl;
  }

  // --- Engine Principal do Quiz ---
  async function runStep(stepIndex) {
    if (stepIndex >= flow.length) return;

    const step = flow[stepIndex];
    currentStep = stepIndex;
    updateProgress(stepIndex);

    sendEvent('step_view', { stepNumber: stepIndex, stepName: step.stepName });

    if (step.messages.length > 0) {
      const extraMessages = step.getExtraMessages ? step.getExtraMessages() : null;
      const isLastGroup = !extraMessages;
      await addBotMessages(step.messages, isLastGroup);

      if (extraMessages) {
        await addBotMessages(extraMessages, true);
      }
    }

    if (step.inputType === 'none') return;

    // Se for o passo de link final (redirecionamento)
    if (step.inputType === 'link') {
      const checkoutUrl = buildCheckoutUrl();
      await showLinkButton(step.linkText, checkoutUrl, step.linkId, step.linkClass);
      
      apiBeacon(`/api/session/${sessionId}/answer`, { stepNumber: stepIndex, stepName: step.stepName, answer: step.linkText });
      apiBeacon(`/api/session/${sessionId}/complete`, {});
      apiBeacon(`/api/session/${sessionId}/event`, { eventType: 'checkout_redirect', eventData: { url: checkoutUrl } });
      return;
    }

    let answer;
    if (step.inputType === 'choice') {
      answer = await showChoices(step.options);
    } else if (step.inputType === 'number') {
      answer = await showNumberInput(step.placeholder, step.min, step.max);
    }

    if (step.variableToSave) {
      vars[step.variableToSave] = answer;
    }

    sendAnswer(stepIndex, step.stepName, answer);

    await sleep(400);
    runStep(stepIndex + 1);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // --- Inicialização ---
  async function init() {
    await startSession();
    runStep(0);
  }

  init();
})();
